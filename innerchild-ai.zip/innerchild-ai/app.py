from flask import Flask, request, jsonify, session
from flask_cors import CORS
import os
import logging
from openai import OpenAI
import uuid
import re
import random
from dotenv import load_dotenv
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
import json

# Load environment variables
load_dotenv()

# Download NLTK data
try:
    nltk.data.find('vader_lexicon')
except:
    nltk.download('vader_lexicon', quiet=True)

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'innerchild-safe-key-2024')
CORS(app)

# Set up logger
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize OpenAI
client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))

# Initialize sentiment analyzer
sia = SentimentIntensityAnalyzer()

class EmotionEngine:
    @staticmethod
    def analyze(text):
        """Analyze emotion from text"""
        text_lower = text.lower()
        
        # Sentiment analysis
        sentiment = sia.polarity_scores(text_lower)
        compound = sentiment['compound']
        
        # Emotion keywords
        emotions = {
            'sadness': ['sad', 'lonely', 'empty', 'hurt', 'cry', 'tears', 'grief'],
            'anxiety': ['anxious', 'worried', 'nervous', 'panic', 'overwhelm', 'stress'],
            'fear': ['scared', 'afraid', 'terrified', 'frightened', 'unsafe'],
            'anger': ['angry', 'mad', 'frustrated', 'irritated', 'annoyed'],
            'joy': ['happy', 'joy', 'excited', 'glad', 'peaceful', 'content']
        }
        
        # Detect primary emotion
        emotion_scores = {}
        for emotion, keywords in emotions.items():
            score = sum([1 for kw in keywords if kw in text_lower])
            emotion_scores[emotion] = score
        
        primary_emotion = max(emotion_scores, key=emotion_scores.get)
        
        # Calculate intensity (0-1)
        intensity = min(abs(compound) * 1.5, 1.0)
        if intensity < 0.2:
            intensity = 0.2
        
        # Special detection
        is_fear = any(word in text_lower for word in emotions['fear']) or 'fear' in primary_emotion
        is_sadness = any(word in text_lower for word in emotions['sadness']) or 'sadness' in primary_emotion
        
        return {
            'primary': primary_emotion,
            'intensity': round(intensity, 2),
            'sentiment': round(compound, 2),
            'is_fear': is_fear,
            'is_sadness': is_sadness,
            'needs_grounding': intensity > 0.7 or is_fear,
            'color': EmotionEngine.get_emotion_color(primary_emotion, intensity)
        }
    
    @staticmethod
    def get_emotion_color(emotion, intensity):
        """Get color based on emotion"""
        colors = {
            'sadness': f'rgb(137, 194, 217, {intensity})',
            'anxiety': f'rgb(255, 180, 162, {intensity})',
            'fear': f'rgb(255, 139, 148, {intensity})',
            'anger': f'rgb(255, 107, 107, {intensity})',
            'joy': f'rgb(255, 209, 102, {intensity})',
            'default': f'rgb(168, 230, 207, {intensity})'
        }
        return colors.get(emotion, colors['default'])

class SafetyLayer:
    @staticmethod
    def filter_response(text):
        """Make response safe and gentle"""
        # Soften harsh language
        replacements = {
            'should': 'could',
            'must': 'might',
            'need to': 'may want to',
            'stupid': 'confusing',
            'hate': 'find difficult',
            'useless': 'challenging'
        }
        
        for old, new in replacements.items():
            text = text.replace(old, new)
        
        # Ensure gentle opening
        if not text.lower().startswith(('i hear', 'i understand', 'that sounds', 'thank you')):
            text = f"I hear you. {text}"
        
        return text
    
    @staticmethod
    def check_crisis(text):
        """Check for crisis keywords"""
        crisis_words = ['suicide', 'kill myself', 'end my life', 'self-harm', 'want to die']
        for word in crisis_words:
            if word in text.lower():
                return True
        return False

# Session storage (in-memory for simplicity)
sessions = {}

def get_session(session_id):
    """Get or create session"""
    if session_id not in sessions:
        sessions[session_id] = {
            'messages': [],
            'emotions': [],
            'created': uuid.uuid4().hex[:8]
        }
    return sessions[session_id]

@app.route('/api/chat', methods=['POST'])
def chat():
    """Main chat endpoint"""
    try:
        data = request.json
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return jsonify({'response': "I'm here to listen...", 'emotion': 'neutral'})
        
        # Get session
        session_id = data.get('session_id', str(uuid.uuid4()))
        session = get_session(session_id)
        
        # Analyze emotion
        emotion_data = EmotionEngine.analyze(user_message)
        
        # Check for crisis
        if SafetyLayer.check_crisis(user_message):
            crisis_response = "I hear you're in deep pain. Please reach out for immediate support:\n• 988 Suicide & Crisis Lifeline\n• Crisis Text Line: Text HOME to 741741\n• Your local emergency services\nI'm here with you."
            return jsonify({
                'response': crisis_response,
                'emotion': emotion_data,
                'session_id': session_id,
                'is_crisis': True
            })
        
        # Prepare context (last 4 messages)
        context = session['messages'][-4:] if session['messages'] else []
        
        # Create system prompt
        system_prompt = f"""You are the user's Inner Child - a gentle, vulnerable, innocent version of themselves.
        
Emotional state: {emotion_data['primary']} (intensity: {emotion_data['intensity']})
Tone: soft, comforting, non-judgmental
        
Speak as the user's younger self using "I" statements:
- "I feel scared when..."
- "That makes me feel..."
- "I need..."
        
Never give advice. Focus on feelings. Validate emotions. Use simple, childlike language.
End with warmth and reassurance.
        
User: "{user_message}"
        
Inner Child:"""
        
        # Generate response
        try:
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[
                    {"role": "system", "content": system_prompt},
                    *[{"role": "user" if msg['role'] == 'user' else "assistant", 
                       "content": msg['content']} for msg in context],
                    {"role": "user", "content": user_message}
                ],
                temperature=0.8,
                max_tokens=150
            )
            
            ai_response = response.choices[0].message.content.strip()
            ai_response = SafetyLayer.filter_response(ai_response)
            
        except Exception as e:
            print(f"OpenAI error: {e}")
            # Fallback responses
            fallbacks = [
                "I'm here with you, feeling what you feel.",
                "Let's just breathe together for a moment.",
                "Your feelings are safe with me.",
                "I'm listening with my whole heart."
            ]
            import random
            ai_response = random.choice(fallbacks)
        
        # Store conversation
        session['messages'].append({'role': 'user', 'content': user_message})
        session['messages'].append({'role': 'assistant', 'content': ai_response})
        session['emotions'].append(emotion_data)
        
        # Keep only recent messages
        if len(session['messages']) > 20:
            session['messages'] = session['messages'][-20:]
        
        return jsonify({
            'response': ai_response,
            'emotion': emotion_data,
            'session_id': session_id,
            'needs_grounding': emotion_data['needs_grounding']
        })
        
    except Exception as e:
        print(f"Error: {e}")
        return jsonify({
            'response': "I'm feeling a little shy... could we try again?",
            'error': str(e)
        }), 500

@app.route('/api/grounding', methods=['GET'])
def grounding():
    """Get grounding exercise"""
    emotion = request.args.get('emotion', 'anxiety')
    
    exercises = {
        'anxiety': {
            'name': '5-4-3-2-1 Grounding',
            'steps': [
                'Look around: Name 5 things you can see',
                'Touch: Notice 4 things you can feel',
                'Listen: Identify 3 sounds you hear',
                'Smell: Notice 2 things you can smell',
                'Taste: Name 1 thing you can taste'
            ],
            'color': '#FFB4A2'
        },
        'sadness': {
            'name': 'Comforting Presence',
            'steps': [
                'Place a hand over your heart',
                'Breathe in slowly: 4 counts',
                'Hold gently: 2 counts',
                'Breathe out: 6 counts',
                'Whisper: "I am here with myself"'
            ],
            'color': '#89C2D9'
        },
        'fear': {
            'name': 'Safe Space Visualization',
            'steps': [
                'Close your eyes gently',
                'Imagine a place where you felt completely safe',
                'Notice colors and sounds there',
                'Picture your younger self being cared for',
                'Stay in this feeling for a few breaths'
            ],
            'color': '#FF8B94'
        }
    }
    
    return jsonify(exercises.get(emotion, exercises['anxiety']))

@app.route('/api/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        'status': 'healthy',
        'service': 'InnerChild AI',
        'sessions': len(sessions)
    })

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    print(f"🌱 InnerChild AI starting on port {port}")
    print(f"📚 Using OpenAI model: gpt-3.5-turbo")
    print(f"💖 Safety features: Active")
    app.run(debug=True, host='0.0.0.0', port=port)