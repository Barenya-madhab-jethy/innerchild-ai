"""
Emotion Engine for InnerChild AI
Analyzes emotional content and provides emotional intelligence features
"""

import re
import json
import nltk
from nltk.sentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
from collections import deque
import time

class EmotionEngine:
    """Core emotion analysis and management engine"""
    
    def __init__(self):
        """Initialize emotion engine with NLTK and emotion dictionaries"""
        try:
            nltk.data.find('vader_lexicon')
            nltk.data.find('punkt')
        except:
            print("Downloading NLTK data...")
            nltk.download('vader_lexicon', quiet=True)
            nltk.download('punkt', quiet=True)
        
        self.sia = SentimentIntensityAnalyzer()
        self.emotion_history = deque(maxlen=50)
        self.session_start_time = time.time()
        
        # Enhanced emotion keyword database
        self.emotion_keywords = {
            'sadness': {
                'keywords': ['sad', 'lonely', 'empty', 'hurt', 'grief', 'lost', 'miss', 'cry', 'tears', 
                            'heartbroken', 'despair', 'hopeless', 'melancholy', 'blue', 'down', 'depressed'],
                'weight': 1.2,
                'color': '#89C2D9',
                'emoji': '😢'
            },
            'anxiety': {
                'keywords': ['anxious', 'worried', 'nervous', 'stress', 'overwhelm', 'panic', 'tense',
                            'uneasy', 'restless', 'apprehensive', 'fret', 'concerned', 'on edge'],
                'weight': 1.3,
                'color': '#FF9E6D',
                'emoji': '😰'
            },
            'fear': {
                'keywords': ['scared', 'afraid', 'fear', 'terrified', 'frightened', 'dread', 'horror',
                            'phobia', 'terror', 'intimidated', 'threatened', 'unsafe', 'vulnerable'],
                'weight': 1.4,
                'color': '#EF476F',
                'emoji': '😨'
            },
            'anger': {
                'keywords': ['angry', 'mad', 'furious', 'rage', 'irritated', 'annoyed', 'frustrated',
                            'resentful', 'bitter', 'hostile', 'outraged', 'livid', 'fuming'],
                'weight': 1.3,
                'color': '#E63946',
                'emoji': '😠'
            },
            'joy': {
                'keywords': ['happy', 'joy', 'excited', 'glad', 'delighted', 'pleased', 'content',
                            'peaceful', 'grateful', 'hopeful', 'optimistic', 'cheerful', 'bliss'],
                'weight': 0.8,
                'color': '#FFD166',
                'emoji': '😊'
            },
            'shame': {
                'keywords': ['ashamed', 'guilty', 'embarrassed', 'humiliated', 'regret', 'remorse',
                            'inadequate', 'worthless', 'failure', 'disgrace', 'disappointed'],
                'weight': 1.5,
                'color': '#A882DD',
                'emoji': '😔'
            },
            'neutral': {
                'keywords': ['okay', 'fine', 'alright', 'normal', 'meh', 'whatever', 'neutral'],
                'weight': 0.5,
                'color': '#8B5FBF',
                'emoji': '😐'
            }
        }
        
        # Grounding triggers
        self.grounding_triggers = {
            'panic': ['panic', 'can\'t breathe', 'overwhelmed', 'losing control'],
            'dissociation': ['numb', 'detached', 'unreal', 'spaced out', 'floating'],
            'flashback': ['memory', 'reminded of', 'triggered', 'reliving'],
            'shutdown': ['exhausted', 'drained', 'empty', 'nothing', 'blank']
        }
        
        # Emotional healing prompts
        self.healing_prompts = {
            'sadness': [
                "Would you like to share more about what's making you feel sad?",
                "It's okay to feel sad. Would a comforting visualization help?",
                "Can you tell me about a time when you felt comforted?"
            ],
            'anxiety': [
                "Let's breathe together. Ready to try a grounding exercise?",
                "What's one small thing that feels manageable right now?",
                "Can you describe what anxiety feels like in your body?"
            ],
            'fear': [
                "You're safe here. Would imagining a safe place help?",
                "What would make you feel a little more safe right now?",
                "Can you tell me about something that makes you feel protected?"
            ]
        }
    
    def analyze(self, text):
        """
        Analyze emotional content of text
        Returns comprehensive emotion data
        """
        if not text or not isinstance(text, str):
            return self._default_emotion()
        
        text_lower = text.lower().strip()
        
        # Get sentiment scores
        sentiment = self.sia.polarity_scores(text_lower)
        compound = sentiment['compound']
        
        # Analyze with TextBlob for additional insights
        blob = TextBlob(text_lower)
        polarity = blob.sentiment.polarity
        subjectivity = blob.sentiment.subjectivity
        
        # Detect emotion through keyword matching
        emotion_scores = {}
        for emotion, data in self.emotion_keywords.items():
            score = 0
            for keyword in data['keywords']:
                if keyword in text_lower:
                    # Weight based on keyword importance
                    score += data['weight']
                    # Additional weight if keyword is emphasized
                    if f"very {keyword}" in text_lower or f"so {keyword}" in text_lower:
                        score += 0.5
            
            # Consider sentiment polarity
            if emotion == 'joy' and polarity > 0.3:
                score += 0.3
            elif emotion in ['sadness', 'anger', 'fear'] and polarity < -0.3:
                score += 0.3
            
            emotion_scores[emotion] = score
        
        # Determine primary and secondary emotions
        sorted_emotions = sorted(emotion_scores.items(), key=lambda x: x[1], reverse=True)
        primary_emotion = sorted_emotions[0][0] if sorted_emotions[0][1] > 0 else 'neutral'
        secondary_emotion = sorted_emotions[1][0] if len(sorted_emotions) > 1 and sorted_emotions[1][1] > 0 else None
        
        # Calculate intensity (0-1)
        intensity = self._calculate_intensity(compound, emotion_scores, subjectivity)
        
        # Detect specific needs
        needs = self._detect_needs(text_lower, primary_emotion, intensity)
        
        # Get emotional color with opacity based on intensity
        emotion_data = self.emotion_keywords.get(primary_emotion, self.emotion_keywords['neutral'])
        color_with_opacity = self._adjust_color_opacity(emotion_data['color'], intensity)
        
        # Create comprehensive emotion object
        emotion_result = {
            'primary': primary_emotion,
            'secondary': secondary_emotion,
            'intensity': round(intensity, 2),
            'sentiment': round(compound, 3),
            'subjectivity': round(subjectivity, 2),
            'color': color_with_opacity,
            'emoji': emotion_data['emoji'],
            'scores': {k: round(v, 2) for k, v in emotion_scores.items() if v > 0},
            'needs': needs,
            'requires_grounding': intensity > 0.7 or any(need in needs for need in ['panic', 'dissociation', 'flashback']),
            'requires_validation': intensity > 0.4,
            'timestamp': time.time(),
            'suggested_response_tone': self._get_response_tone(primary_emotion, intensity)
        }
        
        # Store in history
        self.emotion_history.append(emotion_result)
        
        return emotion_result
    
    def _calculate_intensity(self, compound, emotion_scores, subjectivity):
        """Calculate emotional intensity"""
        # Base intensity from sentiment
        base_intensity = abs(compound)
        
        # Adjust based on strongest emotion score
        max_emotion_score = max(emotion_scores.values())
        emotion_intensity = min(max_emotion_score / 3, 1.0)
        
        # Adjust based on subjectivity
        subjectivity_factor = subjectivity * 0.3
        
        # Combine factors
        intensity = base_intensity * 0.4 + emotion_intensity * 0.4 + subjectivity_factor
        
        # Ensure within bounds
        intensity = max(0.1, min(intensity, 1.0))
        
        # Round to 2 decimal places
        return round(intensity, 2)
    
    def _detect_needs(self, text, primary_emotion, intensity):
        """Detect specific emotional needs"""
        needs = []
        
        # Check for grounding triggers
        for trigger_type, triggers in self.grounding_triggers.items():
            for trigger in triggers:
                if trigger in text:
                    needs.append(trigger_type)
                    break
        
        # Add emotional needs
        if intensity > 0.8:
            needs.append('urgent_care')
        if primary_emotion in ['sadness', 'shame'] and intensity > 0.6:
            needs.append('comfort')
        if primary_emotion == 'fear':
            needs.append('reassurance')
        if primary_emotion == 'anger' and intensity > 0.5:
            needs.append('validation')
        
        # Check for loneliness cues
        lonely_words = ['alone', 'lonely', 'isolated', 'no one', 'by myself']
        if any(word in text for word in lonely_words):
            needs.append('connection')
        
        # Check for confusion
        if 'confus' in text or 'dont know' in text or 'unsure' in text:
            needs.append('clarity')
        
        return list(set(needs))  # Remove duplicates
    
    def _adjust_color_opacity(self, color, intensity):
        """Adjust color opacity based on intensity"""
        # Convert hex to rgba
        if color.startswith('#'):
            r = int(color[1:3], 16)
            g = int(color[3:5], 16)
            b = int(color[5:7], 16)
            opacity = max(0.3, min(intensity, 0.9))
            return f'rgba({r}, {g}, {b}, {opacity})'
        return color
    
    def _get_response_tone(self, emotion, intensity):
        """Get appropriate response tone based on emotion"""
        tones = {
            'high': {
                'sadness': 'gentle, comforting, patient',
                'anxiety': 'calm, reassuring, grounding',
                'fear': 'protective, safe, steady',
                'anger': 'validating, spacious, non-reactive',
                'shame': 'accepting, non-judgmental, gentle',
                'default': 'soft, present, attentive'
            },
            'medium': {
                'sadness': 'warm, understanding, tender',
                'anxiety': 'soothing, present, supportive',
                'fear': 'reassuring, protective, calm',
                'anger': 'understanding, spacious, accepting',
                'shame': 'kind, accepting, gentle',
                'default': 'caring, responsive, gentle'
            },
            'low': {
                'sadness': 'soft, curious, gentle',
                'anxiety': 'light, present, steady',
                'fear': 'comforting, safe, gentle',
                'anger': 'neutral, open, calm',
                'shame': 'soft, accepting, gentle',
                'default': 'gentle, curious, warm'
            }
        }
        
        # Select intensity level
        if intensity > 0.7:
            level = 'high'
        elif intensity > 0.3:
            level = 'medium'
        else:
            level = 'low'
        
        return tones[level].get(emotion, tones[level]['default'])
    
    def _default_emotion(self):
        """Return default neutral emotion"""
        return {
            'primary': 'neutral',
            'secondary': None,
            'intensity': 0.1,
            'sentiment': 0.0,
            'subjectivity': 0.0,
            'color': 'rgba(139, 95, 191, 0.3)',
            'emoji': '😐',
            'scores': {},
            'needs': [],
            'requires_grounding': False,
            'requires_validation': False,
            'timestamp': time.time(),
            'suggested_response_tone': 'gentle, curious, warm'
        }
    
    def get_emotional_trend(self, window=5):
        """Get emotional trend over recent messages"""
        if len(self.emotion_history) < 2:
            return 'stable'
        
        recent = list(self.emotion_history)[-window:]
        intensities = [e['intensity'] for e in recent]
        
        if len(intensities) < 2:
            return 'stable'
        
        # Calculate trend
        first_half = intensities[:len(intensities)//2]
        second_half = intensities[len(intensities)//2:]
        
        avg_first = sum(first_half) / len(first_half)
        avg_second = sum(second_half) / len(second_half)
        
        if avg_second > avg_first + 0.2:
            return 'escalating'
        elif avg_second < avg_first - 0.2:
            return 'calming'
        else:
            return 'stable'
    
    def get_healing_prompt(self, emotion):
        """Get a healing prompt for specific emotion"""
        prompts = self.healing_prompts.get(emotion, [])
        if prompts:
            import random
            return random.choice(prompts)
        return "Would you like to share more about what you're feeling?"
    
    def detect_emotional_exhaustion(self):
        """Detect signs of emotional exhaustion"""
        if len(self.emotion_history) < 10:
            return False
        
        recent = list(self.emotion_history)[-10:]
        
        # Check for high intensity sustained
        high_intensity_count = sum(1 for e in recent if e['intensity'] > 0.7)
        
        # Check for negative sentiment sustained
        negative_count = sum(1 for e in recent if e['sentiment'] < -0.3)
        
        # Check for repeated same emotion
        emotions = [e['primary'] for e in recent]
        if emotions:
            most_common = max(set(emotions), key=emotions.count)
            same_emotion_ratio = emotions.count(most_common) / len(emotions)
        else:
            same_emotion_ratio = 0
        
        return (high_intensity_count > 7 or 
                negative_count > 8 or 
                same_emotion_ratio > 0.8)
    
    def get_emotional_summary(self):
        """Get summary of emotional journey"""
        if not self.emotion_history:
            return "Beginning emotional exploration..."
        
        emotions = [e['primary'] for e in self.emotion_history]
        intensities = [e['intensity'] for e in self.emotion_history]
        
        # Find most frequent emotions
        from collections import Counter
        emotion_counts = Counter(emotions)
        common_emotions = emotion_counts.most_common(3)
        
        avg_intensity = sum(intensities) / len(intensities)
        
        summary = {
            'total_messages': len(self.emotion_history),
            'duration_minutes': (time.time() - self.session_start_time) / 60,
            'common_emotions': common_emotions,
            'average_intensity': round(avg_intensity, 2),
            'emotional_trend': self.get_emotional_trend(),
            'needs_break': self.detect_emotional_exhaustion()
        }
        
        return summary
    
    def get_grounding_suggestion(self, emotion_type):
        """Get appropriate grounding suggestion"""
        suggestions = {
            'panic': {
                'name': '5-4-3-2-1 Sensory Grounding',
                'description': 'Connect with your senses to anchor in the present',
                'duration': 90,
                'steps': [
                    'Look around: Name 5 things you can see',
                    'Touch: Notice 4 things you can feel',
                    'Listen: Identify 3 sounds you hear',
                    'Smell: Notice 2 things you can smell',
                    'Taste: Name 1 thing you can taste'
                ]
            },
            'dissociation': {
                'name': 'Body Awareness Practice',
                'description': 'Gently reconnect with your physical presence',
                'duration': 120,
                'steps': [
                    'Place your feet flat on the floor',
                    'Notice the weight of your body in the chair',
                    'Wiggle your fingers and toes',
                    'Take 3 slow, deep breaths',
                    'Name one thing you feel in your body right now'
                ]
            },
            'sadness': {
                'name': 'Comforting Heart Space',
                'description': 'Create a gentle space for your feelings',
                'duration': 60,
                'steps': [
                    'Place a hand over your heart',
                    'Breathe in slowly: 4 counts',
                    'Hold gently: 2 counts',
                    'Breathe out: 6 counts',
                    'Whisper: "I am here with these feelings"'
                ]
            },
            'anxiety': {
                'name': 'Calming Breath Wave',
                'description': 'Soothe your nervous system with rhythmic breathing',
                'duration': 90,
                'steps': [
                    'Inhale slowly through your nose: 4 counts',
                    'Hold gently: 2 counts',
                    'Exhale slowly through pursed lips: 6 counts',
                    'Rest: 2 counts',
                    'Repeat 5 times'
                ]
            }
        }
        
        return suggestions.get(emotion_type, suggestions['anxiety'])
    
    def reset_session(self):
        """Reset emotion history for new session"""
        self.emotion_history.clear()
        self.session_start_time = time.time()


# Helper functions
def format_emotion_display(emotion_data):
    """Format emotion data for display"""
    primary = emotion_data['primary']
    emoji = emotion_data['emoji']
    intensity = emotion_data['intensity']
    
    # Create intensity description
    if intensity < 0.3:
        level = "Slightly"
    elif intensity < 0.6:
        level = "Moderately"
    elif intensity < 0.8:
        level = "Quite"
    else:
        level = "Very"
    
    return f"{emoji} {level} {primary.capitalize()}"


def get_emotion_color_palette():
    """Return emotion color palette for UI"""
    return {
        'sadness': '#89C2D9',
        'anxiety': '#FF9E6D',
        'fear': '#EF476F',
        'anger': '#E63946',
        'joy': '#FFD166',
        'shame': '#A882DD',
        'neutral': '#8B5FBF',
        'calm': '#06D6A0'
    }


# Example usage
if __name__ == "__main__":
    # Test the emotion engine
    engine = EmotionEngine()
    
    test_messages = [
        "I'm feeling really anxious about tomorrow",
        "I'm so sad and lonely tonight",
        "Everything feels overwhelming and I don't know what to do",
        "I'm actually feeling pretty good today!",
        "I'm scared something bad will happen"
    ]
    
    print("🧪 Testing Emotion Engine...\n")
    
    for msg in test_messages:
        result = engine.analyze(msg)
        print(f"Message: {msg}")
        print(f"Emotion: {result['primary']} {result['emoji']}")
        print(f"Intensity: {result['intensity']}")
        print(f"Needs: {result['needs']}")
        print(f"Color: {result['color']}")
        print(f"Tone: {result['suggested_response_tone']}")
        print("-" * 50)
    
    # Test emotional summary
    print("\n📊 Emotional Summary:")
    summary = engine.get_emotional_summary()
    for key, value in summary.items():
        print(f"{key}: {value}")