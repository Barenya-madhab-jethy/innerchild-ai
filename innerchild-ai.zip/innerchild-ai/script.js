// InnerChild AI - Main Application
class InnerChildApp {
    constructor() {
        this.apiBase = 'http://localhost:5000/api';
        this.sessionId = this.generateSessionId();
        this.isTyping = false;
        this.emotionState = 'calm';
        this.emotionIntensity = 0.3;
        this.currentTimer = null;
        
        this.init();
    }
    
    generateSessionId() {
        return 'innerchild_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }
    
    init() {
        // DOM Elements
        this.elements = {
            messageInput: document.getElementById('messageInput'),
            sendBtn: document.getElementById('sendBtn'),
            chatMessages: document.getElementById('chatMessages'),
            typingIndicator: document.getElementById('typingIndicator'),
            emotionCircle: document.getElementById('emotionCircle'),
            emotionText: document.getElementById('emotionText'),
            intensityFill: document.getElementById('intensityFill'),
            sessionId: document.getElementById('sessionId'),
            darkModeBtn: document.getElementById('darkModeBtn'),
            resetBtn: document.getElementById('resetBtn'),
            groundingModal: document.getElementById('groundingModal'),
            startExercise: document.getElementById('startExercise'),
            closeModal: document.getElementById('closeModal'),
            exerciseTitle: document.getElementById('exerciseTitle'),
            exerciseSteps: document.getElementById('exerciseSteps'),
            timerValue: document.getElementById('timerValue')
        };
        
        // Set session ID
        this.elements.sessionId.textContent = this.sessionId.slice(-8);
        
        // Event Listeners
        this.setupEventListeners();
        this.setupAutoResize();
        
        // Initialize dark mode
        this.initDarkMode();
        
        // Show welcome after delay
        setTimeout(() => this.showWelcomeTips(), 1000);
        
        console.log('🌱 InnerChild AI Ready');
    }
    
    setupEventListeners() {
        // Send message
        this.elements.sendBtn.addEventListener('click', () => this.sendMessage());
        this.elements.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });
        
        // Dark mode toggle
        this.elements.darkModeBtn.addEventListener('click', () => this.toggleDarkMode());
        
        // Reset session
        this.elements.resetBtn.addEventListener('click', () => this.resetSession());
        
        // Grounding modal
        this.elements.closeModal.addEventListener('click', () => this.hideModal());
        this.elements.startExercise.addEventListener('click', () => this.startExercise());
        
        // Quick action buttons
        document.querySelectorAll('.action-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = e.currentTarget.dataset.action;
                this.handleQuickAction(action);
            });
        });
        
        // Voice input (simulated)
        document.getElementById('voiceBtn').addEventListener('click', () => this.simulateVoiceInput());
    }
    
    setupAutoResize() {
        const textarea = this.elements.messageInput;
        textarea.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = Math.min(this.scrollHeight, 150) + 'px';
        });
    }
    
    initDarkMode() {
        const isDark = localStorage.getItem('innerchild_darkmode') === 'true';
        if (isDark) {
            document.body.classList.add('dark-mode');
            this.elements.darkModeBtn.innerHTML = '<i class="fas fa-sun"></i>';
        }
    }
    
    toggleDarkMode() {
        document.body.classList.toggle('dark-mode');
        const isDark = document.body.classList.contains('dark-mode');
        localStorage.setItem('innerchild_darkmode', isDark);
        
        this.elements.darkModeBtn.innerHTML = isDark 
            ? '<i class="fas fa-sun"></i>'
            : '<i class="fas fa-moon"></i>';
    }
    
    async sendMessage() {
        const message = this.elements.messageInput.value.trim();
        if (!message) return;
        
        // Add user message
        this.addMessage('user', message);
        
        // Clear input
        this.elements.messageInput.value = '';
        this.elements.messageInput.style.height = 'auto';
        
        // Show typing
        this.showTyping(true);
        
        try {
            const response = await axios.post(`${this.apiBase}/chat`, {
                message: message,
                session_id: this.sessionId
            });
            
            this.showTyping(false);
            
            // Handle crisis response
            if (response.data.is_crisis) {
                this.showCrisisAlert();
            }
            
            // Add AI response
            this.addMessage('ai', response.data.response);
            
            // Update emotion display
            if (response.data.emotion) {
                this.updateEmotion(response.data.emotion);
                
                // Suggest grounding if needed
                if (response.data.needs_grounding) {
                    setTimeout(() => this.suggestGrounding(response.data.emotion.primary), 1500);
                }
            }
            
            this.scrollToBottom();
            
        } catch (error) {
            console.error('Chat error:', error);
            this.showTyping(false);
            this.addMessage('ai', "I'm feeling a little shy... could we try that again?");
        }
    }
    
    addMessage(role, content) {
        const container = document.createElement('div');
        container.className = 'message-container';
        
        const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        
        container.innerHTML = `
            <div class="message-bubble ${role}">
                <div class="message-content">${this.formatContent(content)}</div>
                <div class="message-time">${time}</div>
            </div>
        `;
        
        this.elements.chatMessages.appendChild(container);
        this.scrollToBottom();
    }
    
    formatContent(text) {
        return text
            .replace(/\n/g, '<br>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>');
    }
    
    showTyping(show) {
        this.isTyping = show;
        this.elements.typingIndicator.classList.toggle('active', show);
        if (show) this.scrollToBottom();
    }
    
    updateEmotion(emotionData) {
        this.emotionState = emotionData.primary;
        this.emotionIntensity = emotionData.intensity;
        
        // Update circle
        const circle = this.elements.emotionCircle;
        const text = this.elements.emotionText;
        const fill = this.elements.intensityFill;
        
        // Emotion colors
        const colors = {
            sadness: 'linear-gradient(135deg, var(--sadness), #06D6A0)',
            anxiety: 'linear-gradient(135deg, var(--anxiety), #FFD166)',
            fear: 'linear-gradient(135deg, var(--fear), #EF476F)',
            joy: 'linear-gradient(135deg, var(--joy), #06D6A0)',
            calm: 'linear-gradient(135deg, var(--calm), var(--secondary))'
        };
        
        circle.style.background = colors[this.emotionState] || colors.calm;
        text.textContent = this.emotionState.charAt(0).toUpperCase() + this.emotionState.slice(1);
        fill.style.width = `${this.emotionIntensity * 100}%`;
        
        // Add pulse animation
        circle.style.animation = 'none';
        setTimeout(() => {
            circle.style.animation = 'gentle-pulse 2s ease-in-out';
        }, 10);
    }
    
    async suggestGrounding(emotion) {
        const messages = [
            "Would you like to try a gentle calming exercise together?",
            "I notice some tension. Would a grounding exercise help?",
            "Let's take a moment to breathe together. Would that help?"
        ];
        
        const randomMsg = messages[Math.floor(Math.random() * messages.length)];
        this.addMessage('ai', randomMsg);
        
        // Auto-show grounding after 3 seconds if no response
        setTimeout(async () => {
            await this.showGroundingExercise(emotion);
        }, 3000);
    }
    
    async showGroundingExercise(emotion = 'anxiety') {
        try {
            const response = await axios.get(`${this.apiBase}/grounding?emotion=${emotion}`);
            const exercise = response.data;
            
            this.elements.exerciseTitle.textContent = exercise.name;
            this.elements.exerciseSteps.innerHTML = '';
            
            exercise.steps.forEach((step, index) => {
                const stepDiv = document.createElement('div');
                stepDiv.className = 'step';
                stepDiv.innerHTML = `
                    <div class="step-number">${index + 1}</div>
                    <div class="step-text">${step}</div>
                `;
                this.elements.exerciseSteps.appendChild(stepDiv);
            });
            
            this.elements.groundingModal.classList.add('active');
        } catch (error) {
            console.error('Error loading exercise:', error);
        }
    }
    
    hideModal() {
        this.elements.groundingModal.classList.remove('active');
        if (this.currentTimer) {
            clearInterval(this.currentTimer);
            this.currentTimer = null;
        }
    }
    
    startExercise() {
        let timeLeft = 60;
        const timerElement = this.elements.timerValue;
        const startBtn = this.elements.startExercise;
        
        startBtn.innerHTML = '<i class="fas fa-pause"></i> Pause Exercise';
        startBtn.onclick = () => this.pauseExercise();
        
        this.currentTimer = setInterval(() => {
            timeLeft--;
            timerElement.textContent = timeLeft;
            
            if (timeLeft <= 0) {
                clearInterval(this.currentTimer);
                this.completeExercise();
            }
        }, 1000);
    }
    
    pauseExercise() {
        clearInterval(this.currentTimer);
        this.elements.startExercise.innerHTML = '<i class="fas fa-play"></i> Resume Exercise';
        this.elements.startExercise.onclick = () => this.startExercise();
    }
    
    completeExercise() {
        this.elements.startExercise.innerHTML = '<i class="fas fa-check"></i> Complete!';
        this.elements.startExercise.style.background = 'linear-gradient(135deg, var(--secondary), var(--calm))';
        
        setTimeout(() => {
            this.hideModal();
            this.addMessage('ai', "That was really brave. How do you feel after taking that calming time?");
            
            // Reset button
            setTimeout(() => {
                this.elements.startExercise.innerHTML = '<i class="fas fa-play"></i> Begin Calming';
                this.elements.startExercise.style.background = 'linear-gradient(135deg, var(--primary), var(--primary-dark))';
                this.elements.startExercise.onclick = () => this.startExercise();
            }, 1000);
        }, 2000);
    }
    
    handleQuickAction(action) {
        const actions = {
            breathing: () => {
                this.addMessage('ai', "Let's breathe together... Inhale slowly for 4 counts... hold for 2... exhale for 6. I'm breathing with you.");
            },
            safeplace: () => {
                this.addMessage('ai', "Imagine a safe place... A cozy corner, a sunny spot in nature, or a childhood memory where you felt completely protected. What does it look like there?");
            },
            letter: () => {
                this.addMessage('ai', "Would you like to write a letter to your younger self? You could offer comfort for something that was hard, or share what you wish someone had told you.");
            }
        };
        
        if (actions[action]) {
            actions[action]();
            this.scrollToBottom();
        }
    }
    
    simulateVoiceInput() {
        const voiceBtn = document.getElementById('voiceBtn');
        voiceBtn.style.background = 'var(--danger)';
        voiceBtn.style.color = 'white';
        
        this.addMessage('ai', "Voice input is coming soon! For now, please type your message.");
        
        setTimeout(() => {
            voiceBtn.style.background = '';
            voiceBtn.style.color = '';
        }, 2000);
    }
    
    resetSession() {
        if (confirm("Start a new conversation? This will clear the current chat.")) {
            this.sessionId = this.generateSessionId();
            this.elements.sessionId.textContent = this.sessionId.slice(-8);
            this.elements.chatMessages.innerHTML = '';
            this.updateEmotion({ primary: 'calm', intensity: 0.3 });
            this.showWelcomeMessage();
        }
    }
    
    showWelcomeMessage() {
        this.elements.chatMessages.innerHTML = `
            <div class="welcome-message">
                <div class="welcome-bubble">
                    <div class="welcome-avatar">👶</div>
                    <div class="welcome-content">
                        <h3>Hello, I'm your Inner Child</h3>
                        <p>I'm here to listen gently, without any judgment. You can share anything you're feeling - joy, sadness, fear, or confusion.</p>
                        <p class="welcome-tip"><i class="fas fa-lightbulb"></i> I'll respond as your younger, more vulnerable self</p>
                    </div>
                </div>
            </div>
        `;
    }
    
    showWelcomeTips() {
        const tips = [
            "Try sharing how you're feeling right now",
            "You can say 'I feel...' or 'I need...'",
            "There are no right or wrong feelings here",
            "Use the quick buttons for calming exercises"
        ];
        
        const tip = tips[Math.floor(Math.random() * tips.length)];
        console.log(`💡 Tip: ${tip}`);
    }
    
    showCrisisAlert() {
        const alertDiv = document.createElement('div');
        alertDiv.className = 'crisis-alert';
        alertDiv.innerHTML = `
            <div class="alert-content">
                <i class="fas fa-exclamation-triangle"></i>
                <div>
                    <h4>Important Resources</h4>
                    <p>If you're in crisis, please reach out:</p>
                    <ul>
                        <li>988 Suicide & Crisis Lifeline</li>
                        <li>Crisis Text Line: Text HOME to 741741</li>
                        <li>Your local emergency services</li>
                    </ul>
                </div>
            </div>
        `;
        
        document.body.appendChild(alertDiv);
        
        setTimeout(() => {
            alertDiv.remove();
        }, 10000);
    }
    
    scrollToBottom() {
        setTimeout(() => {
            this.elements.chatMessages.scrollTop = this.elements.chatMessages.scrollHeight;
        }, 100);
    }
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', () => {
    window.app = new InnerChildApp();
});